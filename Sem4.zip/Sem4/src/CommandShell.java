import java.io.*;
import java.nio.file.FileAlreadyExistsException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

public class CommandShell {


    public static void main(String[] args) throws IOException {
        String commandLine;
        Scanner scanner = new Scanner(System.in);
        System.out.println("\n\n***** Welcome to the Java Command Shell *****");
        System.out.println("If you want to exit the shell, type END and press RETURN.\n");
    
        while (true) {
               System.out.print("jsh>");
            commandLine = scanner.nextLine();
            // if user entered a return, just loop again
            List<String> lines = Arrays.asList(commandLine.split(" "));
            if (commandLine.equals("")) {
                continue;
            }
            else if(commandLine.toLowerCase().startsWith("filedump")) { //task1
                if (lines.size() < 2){
                    System.out.println("Need more parameters.");
                    continue;
                }
                List<String> contents = readFile(lines);
                for (String line : contents){
                    System.out.println(line);
                }
            }
            else if (commandLine.toLowerCase().startsWith("copyfile")) { //task2
                if (lines.size() < 3){
                    System.out.println("Need more parameters.");
                    continue;
                }
                List<String> fileLines = readFile(lines);
                writeFile(lines, fileLines);

            }
            else if (commandLine.toLowerCase().startsWith("createfile")) { //task3
                if (lines.size() < 2){
                    System.out.println("Need more parameters.");
                    continue;
                }
                createFile(lines);
            }
            else if (commandLine.toLowerCase().equals("end")) { //User wants to end shell
                System.out.println("\n***** Command Shell Terminated. See you next time. BYE for now. *****\n");
                scanner.close();
                System.exit(0);
            }
            else{
                System.out.println("Unknown command.");
            }
        }   
    }

    static List<String> readFile(List<String> lines) throws IOException {
        BufferedReader bufferReader = null;
        List<String> fileLines = new ArrayList<String>();
        try {
            File file = new File(lines.get(1));
            bufferReader = new BufferedReader(new FileReader(file));

            String line;
            while ((line = bufferReader.readLine()) != null) {
                fileLines.add(line);
            }
        } catch (FileNotFoundException e) {
            System.err.println("Error");
            System.err.println(e);
        } finally {
            if (bufferReader != null) {
                bufferReader.close();
            }
        }
        return fileLines;
    } //task 1 and part of 2

    static void writeFile(List<String> lines, List<String> writeLines) throws IOException {
        BufferedWriter bufferWriter = null;
        try {
            File file = new File(lines.get(2));
            bufferWriter = new BufferedWriter(new FileWriter(file));

            for (String line :writeLines) {
                bufferWriter.append(line+"\n");
            }
        } catch (FileNotFoundException e) {
            System.err.println("Error");
            System.err.println(e);
        } finally {
            if (bufferWriter != null) {
                bufferWriter.close();
            }
        }
    } //task 2

    static void createFile(List<String> lines) throws IOException {
        try {
            Files.createFile(Path.of(lines.get(1)));
        }catch (FileAlreadyExistsException faee){
            System.err.println("Error. The file you are trying to create already exists.");
            System.err.println(faee);
        }
    } //task 3
}
