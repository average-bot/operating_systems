package com.company;

import java.text.DecimalFormat;

public class StopWatch extends Thread {
    public double time = 0;
    private static DecimalFormat df2 = new DecimalFormat("#.##"); //https://mkyong.com/java/java-display-double-in-2-decimal-points/

    public void run(){
        try {
            while(this.time<=60) {
                System.out.println("Stopwatch thread. Elapsed: " + df2.format(time) + "seconds." );
                System.out.println(Thread.currentThread().getName());
                this.time += 0.01;
                Thread.sleep(10);
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args){
        System.out.println(Thread.currentThread().getName() + " thread. Waiting for stopwatch thread...");
        StopWatch firstThread = new StopWatch();
        firstThread.start();
        try
        {
            System.out.println("Current Thread: "
                    + Thread.currentThread().getName());
            firstThread.join();
        }
        catch(Exception ex)
        {
            System.out.println("Exception " + ex);
        }

        System.out.println(Thread.currentThread().getName() + "Main thread. Threads joined. Finished stopwatch thread.");
    }
}
