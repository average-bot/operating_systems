import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class test {
    public static void main(String[] args) {
        double[] helloTable = new double[10];
        for (int n = 0; n < 10; n++) {
            helloTable[n] = -1;
        }

        List<Double> list1 = new ArrayList<Double>();
        //Collections.addAll(list1, helloTable);
        System.out.println(list1);

        helloTable[2] = 2;
        System.out.println(helloTable);
        List<double[]> list = Collections.singletonList(helloTable);
        System.out.println(list);
        System.out.println(list.get(2));
    }
}
