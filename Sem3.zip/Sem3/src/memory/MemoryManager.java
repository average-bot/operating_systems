package memory;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.*;

public class MemoryManager {

	private int myNumberOfPages;
	private int myPageSize; // In bytes
	private int myNumberOfFrames;
	private int[] myPageTable; // -1 if page is not in physical memory
	private byte[] myRAM; // physical memory RAM
	private RandomAccessFile myPageFile;
	private int myNextFreeFramePosition = 0;//counter for putting the first X frames in the queue
	private int myNumberOfpageFaults = 0;
	private int myPageReplacementAlgorithm = 0;

	private Deque<Integer> prioQueue = new LinkedList<Integer>(); // queue for frames
	private Hashtable<Integer, Integer> dict = new Hashtable<Integer, Integer>(); //dictionary or hashmap for logging the current pages in frames

	public MemoryManager(int numberOfPages, int pageSize, int numberOfFrames, String pageFile,
			int pageReplacementAlgorithm) {

		myNumberOfPages = numberOfPages;
		myPageSize = pageSize;
		myNumberOfFrames = numberOfFrames;
		myPageReplacementAlgorithm = pageReplacementAlgorithm;

		prioQueue.addFirst(-1);

		initPageTable();
		myRAM = new byte[myNumberOfFrames * myPageSize];

		try {
			myPageFile = new RandomAccessFile(pageFile, "r");
		} catch (FileNotFoundException ex) {
			System.out.println("Can't open page file: " + ex.getMessage());
		}
	}

	private void initPageTable() {
		myPageTable = new int[myNumberOfPages];
		for (int n = 0; n < myNumberOfPages; n++) {
			myPageTable[n] = -1;
		}
	}

	public byte readFromMemory(int logicalAddress) {
		int pageNumber = getPageNumber(logicalAddress);
		int offset = getPageOffset(logicalAddress);


		// task 1
		//if (myPageTable[pageNumber] == -1) {
		//	pageFault(pageNumber);
		//}

		// task 2 & 3
		if (prioQueue.peek() == (-1)) {
			pageFault(pageNumber);
		}



		int frame = myPageTable[pageNumber];
		int physicalAddress = frame * myPageSize + offset;
		byte data = myRAM[physicalAddress];

		System.out.print("Virtual address: " + logicalAddress);
		System.out.print(" Physical address: " + physicalAddress);
		System.out.println(" Value: " + data);
		return data;
	}

	private int getPageNumber(int logicalAddress) { // from addresses.txt
		// Implement by student in task one
		// return logicalAddress / myPageSize;
		return logicalAddress >> 8; // shift all bits 8 steps to the right
	}

	private int getPageOffset(int logicalAddress) {  // from addresses.txt
		// Implement by student in task one
		// return logicalAddress % myPageSize;
		return logicalAddress & 0b0000000011111111;
	}

	private void pageFault(int pageNumber) {
		if (myPageReplacementAlgorithm == Seminar3.NO_PAGE_REPLACEMENT)
			handlePageFault(pageNumber);

		if (myPageReplacementAlgorithm == Seminar3.FIFO_PAGE_REPLACEMENT)
			handlePageFaultFIFO(pageNumber);

		if (myPageReplacementAlgorithm == Seminar3.LRU_PAGE_REPLACEMENT)
			handlePageFaultLRU(pageNumber);

		readFromPageFileToMemory(pageNumber);
	}

	private void readFromPageFileToMemory(int pageNumber) {
		try {
			int frame = myPageTable[pageNumber];
			myPageFile.seek(pageNumber * myPageSize);
			for (int b = 0; b < myPageSize; b++)
				myRAM[frame * myPageSize + b] = myPageFile.readByte();
		} catch (IOException ex) {

		}
	}

	public int getNumberOfPageFaults() {
		return myNumberOfpageFaults;
	}

	private void handlePageFault(int pageNumber){ //fits perfectly in memory since nrofPages== nrofFrames
		myPageTable[pageNumber] = myNextFreeFramePosition;
		myNextFreeFramePosition++;
		myNumberOfpageFaults++;
		// Implement by student in task one
		// This is the simple case where we assume same size of physical and logical
		// memory
		// nextFreeFramePosition is used to point to next free frame position

	}

	private void handlePageFaultFIFO(int pageNumber) { // first in first out
		//dict key:frame value:page
		//prioQueue frames
		if (!(dict.containsValue(pageNumber))){ //if the pageNumber doesn't exist in the dictionary its a page error
			prioQueue.poll(); //polling -1 from the beginning of the queue
			int frameToReplace;
			if (myNumberOfpageFaults < myNumberOfFrames){
				frameToReplace=myNextFreeFramePosition;
				myNextFreeFramePosition++;
			}
			else{
				frameToReplace = prioQueue.poll();
			}

			dict.remove(frameToReplace);
			myPageTable[pageNumber] = frameToReplace;
			dict.put(frameToReplace, pageNumber);
			prioQueue.add(frameToReplace);

			myNumberOfpageFaults++; //move it only to when there is a page fault
			prioQueue.offerFirst(-1); // ADDING -1 to the start of the queue to make it go to this method
		}

		//else its not a page fault


		//for testing
		//System.out.println(dict);
		//System.out.println(prioQueue);
		//System.out.println(myNextFreeFramePosition);
		//System.out.println(prioQueue.peek());



		// Implement by student in task two
		// this solution allows different size of physical and logical memory
		// page replacement using FIFO
		// Note depending on your solution, you might need to change parts of the
		// supplied code, this is allowed.
	}

	private void handlePageFaultLRU(int pageNumber) { // Least Recently Used
		// dict key:frame value:page
		//prioQueue frames
		if (!(dict.containsValue(pageNumber))) { //if the pageNumber doesn't exist in the dictionary
			prioQueue.poll();
			int frameToReplace;
			if (myNumberOfpageFaults < myNumberOfFrames) {
				frameToReplace = myNextFreeFramePosition;
				myNextFreeFramePosition++;
			} else {
				frameToReplace = prioQueue.poll();
			}

			dict.remove(frameToReplace);
			myPageTable[pageNumber] = frameToReplace;
			dict.put(frameToReplace, pageNumber);
			prioQueue.add(frameToReplace);

			myNumberOfpageFaults++; //move it only to when there is a page fault
			prioQueue.offerFirst(-1); // ADDING -1 to the start of the queue to make it go to this method
		}
		else if (dict.containsValue(pageNumber)) { // if the pagenumber is already in the queue
			//put it in the end of the queue
			prioQueue.remove(myPageTable[pageNumber]);
			prioQueue.add(myPageTable[pageNumber]);
		}
		// Implement by student in task three
		// this solution allows different size of physical and logical memory
		// page replacement using LRU
		// Note depending on your solution, you might need to change parts of the
		// supplied code, this is allowed.
	}
}
