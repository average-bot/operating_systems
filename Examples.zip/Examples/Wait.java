public class Wait implements Runnable {

	private static final String THREAD_THREE_NAME = "three";
	private static final String THREAD_TWO_NAME = "two";
	private static final String THREAD_ONE_NAME = "one";

	private static boolean databaseStarted = false;

	public void run() 
	{
		
		if("three".equals(Thread.currentThread().getName()))
			startDatabase();
		
		else
		{
			queryDatabase();
		}
		
	}
	
	public synchronized void startDatabase()
	{
		System.out.println("start database");
		databaseStarted = true;
		notifyAll();
	}

	public synchronized void queryDatabase()
	{
		if(databaseStarted == false)
		try {
			wait();
		} 
		catch (InterruptedException e) 
		{
			e.printStackTrace();
		}
		
		if(databaseStarted == true)
		{
			System.out.println("Database query....." );
			System.out.println("Current Thread: " + Thread.currentThread().getName());
		}
	}
	

	public static void main(String args[]) 
	{
		Wait example = new Wait();
		Thread threadOne = new Thread(example);
		threadOne.setName(THREAD_ONE_NAME);
		threadOne.start();

		Thread threadTwo = new Thread(example);
		threadTwo.setName(THREAD_TWO_NAME);
		threadTwo.start();

		Thread threadThree = new Thread(example);
		threadThree.setName(THREAD_THREE_NAME);
		threadThree.start();

		try 
		{
			threadOne.join();
			threadTwo.join();
			threadThree.join();
		} 
		catch (Exception ex)
		{
			System.out.println("Exception " + ex);
		}
	}
}
