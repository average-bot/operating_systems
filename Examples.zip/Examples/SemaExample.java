import java.util.concurrent.Semaphore;

public class SemaExample implements Runnable {

	private static final String THREAD_THREE_NAME = "three";
	private static final String THREAD_TWO_NAME = "two";
	private static final String THREAD_ONE_NAME = "one";
	
	private static Semaphore sem = new Semaphore(3);
	
	private static int shared = 1;
	
	public void run() 
	{
		doWork();
	}

	private void doWork() 
	{
			for(int i = 0; i < 10; i++)
			{
				try {
					accessSharedResource();
				} catch (InterruptedException e) {
				
					e.printStackTrace();
				}
			
			}
	}
		
	
	private void accessSharedResource() throws InterruptedException 
	{
		System.out.println("Thread " + Thread.currentThread().getName() +  " is waiting for a permit.");	
		sem.acquire();
		System.out.println("Thread " + Thread.currentThread().getName() +  " gets a permit.");
		
				
		
		System.out.println("Thread " + Thread.currentThread().getName()  + " access shared resource" + shared) ;
						
		Thread.sleep(5000);
	
		sem.release();
		System.out.println("Thread " + Thread.currentThread().getName() +  " released a permit.");

	}


	public static void main(String args[]) 
	{
		
		System.out.println("Number of permits:" + sem.availablePermits());
		SemaExample example = new SemaExample();
		Thread threadOne = new Thread(example);
		threadOne.setName(THREAD_ONE_NAME);
		threadOne.start();

		Thread threadTwo = new Thread(example);
		threadTwo.setName(THREAD_TWO_NAME);
		threadTwo.start();

		Thread threadThree = new Thread(example);
		threadThree.setName(THREAD_THREE_NAME);
		threadThree.start();
	}
}
