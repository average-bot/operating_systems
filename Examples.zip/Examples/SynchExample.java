public class SynchExample implements Runnable {

	private static final int MAX_SEQUENCE_NUMBER = 1000;
	private static final String THREAD_THREE_NAME = "three";
	private static final String THREAD_TWO_NAME = "two";
	private static final String THREAD_ONE_NAME = "one";

	private static int sequenceNumber = 0;

	public void run() 
	{
		handleSequenceNumber();
	}

	private void handleSequenceNumber() 
	{
		while (true) 
		{
			synchronized (this) 
			{
				if (getSequenceNumber() < MAX_SEQUENCE_NUMBER + 1)
				{
					print();
					increaseSequenceNumber();

					try
					{

						Thread.sleep(10);
					} 
					catch (InterruptedException e) 
					{
						e.printStackTrace();
					}
				} 
				else 
				{
					break;
				}
			}
		}
	}

	private  int increaseSequenceNumber() 
	{
		return sequenceNumber++;
	}

	private int getSequenceNumber() 
	{
		return sequenceNumber;
	}

	private void print() 
	{
		Thread thread = Thread.currentThread();
		System.out.println("Thread running: Name: " + thread.getName() + " Thread running Id: " + thread.getId()
						    + " SequenceNumber: " + getSequenceNumber());
	}

	public static void main(String args[]) 
	{
		SynchExample example = new SynchExample();
		Thread threadOne = new Thread(example);
		threadOne.setName(THREAD_ONE_NAME);
		threadOne.start();

		Thread threadTwo = new Thread(example);
		threadTwo.setName(THREAD_TWO_NAME);
		threadTwo.start();

		Thread threadThree = new Thread(example);
		threadThree.setName(THREAD_THREE_NAME);
		threadThree.start();

		try 
		{
			System.out.println("Current Thread: " + Thread.currentThread().getName());
			threadOne.join();
			threadTwo.join();
			threadThree.join();
		} 
		catch (Exception ex)
		{
			System.out.println("Exception " + ex);
		}
		System.out.println("Threads joined");
	}
}
